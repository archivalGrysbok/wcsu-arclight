module.exports = require('./conformsTo');
