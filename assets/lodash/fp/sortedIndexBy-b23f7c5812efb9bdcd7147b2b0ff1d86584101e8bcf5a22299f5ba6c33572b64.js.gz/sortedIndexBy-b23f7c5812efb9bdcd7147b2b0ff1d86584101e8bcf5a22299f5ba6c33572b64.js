var convert = require('./convert'),
    func = convert('sortedIndexBy', require('../sortedIndexBy'));

func.placeholder = require('./placeholder');
module.exports = func;
