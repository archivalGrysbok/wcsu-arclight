const set = require('regenerate')();
set.addRange(0x1700, 0x170C).addRange(0x170E, 0x1714).addRange(0x1735, 0x1736);
module.exports = set;
