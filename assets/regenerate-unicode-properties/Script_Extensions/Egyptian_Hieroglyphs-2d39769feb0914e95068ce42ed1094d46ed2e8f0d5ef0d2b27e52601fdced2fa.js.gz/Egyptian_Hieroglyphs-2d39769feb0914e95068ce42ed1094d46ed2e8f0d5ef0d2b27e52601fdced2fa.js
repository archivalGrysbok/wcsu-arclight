const set = require('regenerate')();
set.addRange(0x13000, 0x1342E).addRange(0x13430, 0x13438);
module.exports = set;
