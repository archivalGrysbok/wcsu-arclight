const set = require('regenerate')();
set.addRange(0x1720, 0x1734);
module.exports = set;
