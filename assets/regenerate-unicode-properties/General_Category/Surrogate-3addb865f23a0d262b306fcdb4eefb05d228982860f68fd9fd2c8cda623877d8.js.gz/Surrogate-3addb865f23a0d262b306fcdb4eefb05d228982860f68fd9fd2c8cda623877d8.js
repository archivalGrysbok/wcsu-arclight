const set = require('regenerate')();
set.addRange(0xD800, 0xDFFF);
module.exports = set;
