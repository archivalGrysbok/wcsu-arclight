var convert = require('./convert'),
    func = convert('wrapperLodash', require('../wrapperLodash'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
