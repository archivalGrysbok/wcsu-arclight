const set = require('regenerate')();
set.addRange(0x10400, 0x1044F);
module.exports = set;
