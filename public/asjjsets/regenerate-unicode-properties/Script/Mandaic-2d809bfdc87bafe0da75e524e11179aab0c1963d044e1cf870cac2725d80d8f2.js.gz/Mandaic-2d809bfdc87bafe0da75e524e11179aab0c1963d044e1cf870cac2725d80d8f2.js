const set = require('regenerate')(0x85E);
set.addRange(0x840, 0x85B);
module.exports = set;
