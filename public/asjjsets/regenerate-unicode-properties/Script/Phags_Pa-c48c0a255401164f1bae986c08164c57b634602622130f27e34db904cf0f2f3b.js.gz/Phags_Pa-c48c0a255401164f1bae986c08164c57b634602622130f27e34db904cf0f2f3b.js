const set = require('regenerate')();
set.addRange(0xA840, 0xA877);
module.exports = set;
