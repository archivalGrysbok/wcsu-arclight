'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
/*
 * Load this dynamically so that it
 * doesn't appear in the rollup bundle.
 */

var features = exports.features = require('../../data/features');
