module.exports = require('./takeRightWhile');
